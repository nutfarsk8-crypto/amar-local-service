আমার স্থানীয় সেবা কেন্দ্র — Android App Project

এটি একটি Android Studio project। অ্যাপটি native Android shell-এর ভিতরে offline Bengali local-service interface চালায়।

Build:
1. Android Studio খুলুন।
2. এই project folder Open করুন।
3. Gradle sync শেষ হলে Run চাপুন।
4. APK বানাতে Build > Build APK(s) নির্বাচন করুন।

অ্যাপের নাম: আমার স্থানীয় সেবা কেন্দ্র
Package: com.localservicehub.app
Minimum Android: 6.0 (API 23)

নোট: এই পরিবেশে Android SDK/Gradle build tool ইনস্টল না থাকায় এখানে সরাসরি APK binary compile করা সম্ভব হয়নি। Project-টি Android Studio-তে build করার জন্য প্রস্তুত।
